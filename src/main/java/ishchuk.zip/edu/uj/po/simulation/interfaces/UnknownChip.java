package edu.uj.po.simulation.interfaces;

public class UnknownChip extends Exception {
	private static final long serialVersionUID = 2194117550998555485L;
}
