package component.records;

public record PinConnection(int componentId, int pinId) {
}
