package component;

public enum ComponentType {
    CHIP,
    IN_PIN_HEADER,
    OUT_PIN_HEADER
}
