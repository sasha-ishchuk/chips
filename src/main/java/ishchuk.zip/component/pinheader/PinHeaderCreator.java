package component.pinheader;

import component.PinHeaderComponent;

public abstract class PinHeaderCreator {
    public abstract PinHeaderComponent createPinHeader(int size);
}
