package component.pinheader;

public enum PinHeaderType {
    UNSET, IN, OUT
}
