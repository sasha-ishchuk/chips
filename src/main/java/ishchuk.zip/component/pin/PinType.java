package component.pin;

public enum PinType {
    IN, OUT
}
